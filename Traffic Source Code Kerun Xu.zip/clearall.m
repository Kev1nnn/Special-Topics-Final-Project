clear all
